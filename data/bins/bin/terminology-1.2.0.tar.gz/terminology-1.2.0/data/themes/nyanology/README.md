Nyanology: having fun with edje and Terminology
==========

A nyan cat in your term ? That's possible now !


How does it look ?
--------

Demo video: http://www.youtube.com/watch?v=SN5stpMoVs0



What's missing ? (TODO)
--------
 - proper selection. Current one might be fun, but isn't usable
 - stop hacking Terminology's about box, and add our own
 - optional nyan music for the mood


Credits
--------
 - Anisse Astier <anisse@astier.eu>
 - Carsten "Rasterman" Haitzler and the Terminology authors
 - prguitarman for the original nyan cat gif
 - saraj00n for making it popular and the vocaloid music.
