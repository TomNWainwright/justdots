#!/bin/sh
for i in $(seq 1 $1); do
    banner $i;
done
